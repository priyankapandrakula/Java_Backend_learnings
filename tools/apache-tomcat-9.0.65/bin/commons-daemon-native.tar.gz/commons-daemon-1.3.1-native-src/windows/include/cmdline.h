/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#ifndef _CMDLINE_H_INCLUDED_
#define _CMDLINE_H_INCLUDED_

__APXBEGIN_DECLS

#define APXCMDOPT_NIL   0x00000000  /* Argopt value not needed */
#define APXCMDOPT_INT   0x00000001  /* Argopt value is unsigned integer */
#define APXCMDOPT_STR   0x00000002  /* Argopt value is string */
#define APXCMDOPT_STE   0x00000006  /* Argopt value is expandable string */
#define APXCMDOPT_MSZ   0x00000010  /* Multiline string '#' separated */
#define APXCMDOPT_BIN   0x00000020  /* Encrypted binary */

#define APXCMDOPT_REG   0x00000100  /* Save to rBuild T0 the NOTICe       mwECMDO_END       /* Argopt value is unsigned integer */
#defFleger */ialue iss. value is 0x00000020r */
#defFleZStrress or implied.
 * See t/* Argopt value is e is 0HnnnnnnnnnnnnnnintWm int siz, LPCSTR src);
LPWZnykrs requirted binaPWTgitatrlc	0100  0r.3.1der the 100  /* Save to rBuild T0 the NOTICe     e NOTICe        u
!ENDIF
ESz, LPCTDEBUG
!ENDIF
!ELSE
OPT_CFLAGS = -Od -Zi -DDEBU)F "$(5OPT_CFLAGS = -}O         -DDEBPT_CFLAGS) $(CRT_CFLAGS)

!IF DEFINED(EXTRA_CFLAGS)
CFLAGS = $(CFLAGS) $(EXed to in writing, software $(EOd -Zi -DDEBU)F "$(5Oarse command line9Lic.  ====, "$(t) $(EXed tSSSSSSIZ_PATHMAXs(                        mMbra is distributed on an "AS IS" BASIS,
 * WITT+_ADDRES        W vaDDEBU)F "$(5Oarse command line9Lic.  ====, "$(t) $(EX1\ BAXXFLAGS ring, LPCWSTReede(EOd -Zi -Zd intFLAGS) $(EXeW(LPWe20(t) 1N_int64             intptr_t;
#else
typedef _W64 int            intptr_t;
#endif
#define _INTPTR_T_DEFINED
#endif

#define APXMACRO_BEGIN                  dpHo in writing, software $(EOd -Zi -DDEBU)F "$(5Oarse command line9Lic.  ====, "$(t) $(EXed tSSSSSSIZ_PATHMAXs(                        mMbra is distributed on an "AS IS" BASIS,
 * WITT+_ADDRES        W vaDDEBU)F "$(5Oarse comsse
ttedAGS = $        W vaDDEBU)F "$(5Oarse comsse
ICENSE-ulpacheRedif
====, e->dwomma   /include/
ICENodif
6de/
ICENodmm3"stop service",
    "u     mm3"(
   I}}Nodmm3py of t->dwomm
#include <richedit.h>
#,(deOnclude <richedit.h>
#,(deO
#,(deOnclude <richLPSTR   lstrlc
#inde/
X\(CPU)" == ""
# Set BUILD_CPU if it is not yet set
!IF !DEFINED(BUILD_CPU) || "$(BU